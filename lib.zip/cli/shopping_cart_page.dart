import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../model/cart_data.dart';
import 'package:flutter_cli/cli/add_payment_card_page.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final TextEditingController _notesController = TextEditingController();
  String? selectedCardId;
  String? currentStoreId; 
  Map<String, dynamic>? paymentCardData; 

  @override
  void initState() {
    super.initState();
    if (cartItems.isNotEmpty && cartItems.first.storeId != null) {
      currentStoreId = cartItems.first.storeId;
    }
  }

  Future<void> _placeOrder() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      Navigator.pushNamed(context, '/signup');
      return;
    }

    if (currentStoreId == null || currentStoreId!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Error: Store ID not found"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (!userDoc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("User data not found"),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final userData = userDoc.data()!;
      final firstName = userData['first_name'] ?? '';
      final lastName = userData['last_name'] ?? '';
      final email = userData['email'] ?? '';
      final phone = userData['phone'] ?? '';

      int total = cartItems.fold(0, (sum, item) => sum + ((item.price + item.additionPrice) * item.quantity));

      final orderData = {
        "user_id": user.uid,
        "storeId": currentStoreId,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "phone": phone,
        "items": cartItems.map((item) {
          final Map<String, dynamic> itemMap = {
            "name": item.name,
            "price": item.price,
            "quantity": item.quantity,
            "imagePath": item.imagePath,
          };
          if (item.additionName != null && item.additionName!.isNotEmpty) {
            itemMap["additionName"] = item.additionName!;
            itemMap["additionPrice"] = item.additionPrice;
          }
          return itemMap;
        }).toList(),
        "notes": _notesController.text.trim(),
        "total": total,
        "status": "current",
        "timestamp": FieldValue.serverTimestamp(),
        if (paymentCardData != null) "payment_info": paymentCardData,
      };

      DocumentReference orderRef =
          await FirebaseFirestore.instance.collection('Orders').add(orderData);
      String orderId = orderRef.id;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Order placed successfully!"),
          backgroundColor: Colors.green,
        ),
      );

      setState(() {
        cartItems.clear();
      });

      Navigator.pushNamed(context, '/orderEditTimer', arguments: orderId);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("An error occurred while placing the order: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _editProduct(CartItem item) {
    // Show dialog to edit quantity only
    int newQuantity = item.quantity;
    
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text('Edit ${item.name}'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Quantity:'),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove_circle, color: Color(0xFF2A3E5F)),
                        onPressed: () {
                          if (newQuantity > 1) {
                            setDialogState(() {
                              newQuantity--;
                            });
                          }
                        },
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: const Color(0xFF2A3E5F))
                        ),
                        child: Text(
                          '$newQuantity',
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.add_circle, color: Color(0xFF2A3E5F)),
                        onPressed: () {
                          setDialogState(() {
                            newQuantity++;
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Price: ${(item.price + item.additionPrice) * newQuantity} SAR',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2A3E5F),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel', style: TextStyle(color: Colors.red)),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Update quantity in the cart
                    setState(() {
                      item.quantity = newQuantity;
                    });
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2A3E5F),
                  ),
                  child: const Text('Save', style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          }
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    int total = cartItems.fold(0, (sum, item) => sum + ((item.price + item.additionPrice) * item.quantity));

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFFF9F3ED),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF2A3E5F)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Cart',
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
            color: Color(0xFF2A3E5F),
          ),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFF9F3ED),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 20.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: cartItems.isEmpty
                    ? const SizedBox(
                        height: 300,
                        child: Center(child: Text("No items in cart")),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: cartItems.length,
                        itemBuilder: (context, index) =>
                            _buildCartItem(cartItems[index]),
                      ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                color: const Color(0xFFF9F3ED),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _addMoreItemsButton(),
                    const SizedBox(height: 15),
                    const Text(
                      'Add Notes',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2A3E5F),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildNotesField(),
                    const SizedBox(height: 20),
                    const Text(
                      'Payment Method',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2A3E5F),
                      ),
                    ),
                    const SizedBox(height: 10),
                    _buildPaymentMethod(context),
                    const SizedBox(height: 20),
                    _buildTotalSection(total),
                    const SizedBox(height: 15),
                    _placeOrderButton(),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPaymentMethod(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (user != null) ...[
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .collection('payment_cards')
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                print('Error loading cards: ${snapshot.error}');
                return const Text('Error loading cards');
              }
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox(
                  height: 40,
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              final cards = snapshot.data?.docs ?? [];
              if (cards.isEmpty) {
                return const SizedBox.shrink();
              }
              return Container(
                height: 40,
                margin: const EdgeInsets.only(bottom: 15),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: cards.length,
                  itemBuilder: (context, index) {
                    final card = cards[index].data() as Map<String, dynamic>;
                    final cardNumber = card['cardNumber'] as String;
                    final lastFourDigits =
                        cardNumber.substring(cardNumber.length - 4);
                    final isSelected = selectedCardId == cards[index].id;
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedCardId = cards[index].id;
                          paymentCardData = {
                            'cardName': card['cardName'],
                            'cardNumber': card['cardNumber'],
                            'expiry': card['expiry'],
                          };
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF2A3E5F)
                              : Colors.white,
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF2A3E5F)
                                : Colors.grey,
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.credit_card,
                              size: 16,
                              color:
                                  isSelected ? Colors.white : Colors.grey,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '•••• $lastFourDigits',
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.grey,
                                fontSize: 14,
                                fontWeight: isSelected
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ],
        _paymentButton(
          'Pay with VISA',
          Colors.white,
          Colors.blue,
          Icons.credit_card,
          () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AddPayment()),
            ).then((_) => setState(() {}));
          },
        ),
        const SizedBox(height: 10),
        _paymentButton(
          'Pay with Apple Pay',
          Colors.white,
          Colors.black,
          Icons.apple,
          () {
          },
        ),
      ],
    );
  }

  Widget _buildCartItem(CartItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: const Color(0xFF2A3E5F),
            radius: 12,
            child: Text(
              '${item.quantity}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 10),
          _buildImage(item.imagePath),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2A3E5F),
                  ),
                ),
                if (item.additionName != null && item.additionName!.isNotEmpty)
                  Text(
                    'Addition: ${item.additionName} (+${item.additionPrice} SAR)',
                    style: const TextStyle(
                      fontSize: 14,
                      color: Color(0xFF2A3E5F),
                    ),
                  ),
                Text(
                  '${(item.price + item.additionPrice) * item.quantity} SAR',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Color(0xFF2A3E5F),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.edit, color: Color(0xFF2A3E5F)),
            onPressed: () => _editProduct(item),
          ),
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () => setState(() => cartItems.remove(item)),
          ),
        ],
      ),
    );
  }

  Widget _buildImage(String path) {
    return Image.network(
      path,
      width: 50,
      height: 50,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) =>
          Image.asset('assets/placeholder.png', width: 50, height: 50),
    );
  }

  Widget _addMoreItemsButton() {
    return ElevatedButton.icon(
      onPressed: () => Navigator.pop(context),
      icon: const Icon(Icons.add, color: Color(0xFF2A3E5F)),
      label: const Text(
        'Add More Items',
        style: TextStyle(color: Color(0xFF2A3E5F)),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Widget _buildNotesField() {
    return TextField(
      controller: _notesController,
      decoration: InputDecoration(
        hintText: 'I want extra sugar with my tea',
        hintStyle: const TextStyle(color: Color(0xFF2A3E5F)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF2A3E5F)),
        ),
      ),
    );
  }

  Widget _paymentButton(
    String text,
    Color bgColor,
    Color textColor,
    IconData icon,
    VoidCallback onTap,
  ) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, color: textColor),
        label: Text(
          text,
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: bgColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          side: BorderSide(color: textColor),
          minimumSize: const Size(double.infinity, 50),
        ),
      ),
    );
  }

  Widget _buildTotalSection(int total) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          'Total',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF2A3E5F),
          ),
        ),
        Text(
          '$total SAR',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF2A3E5F),
          ),
        ),
      ],
    );
  }

  Widget _placeOrderButton() {
    return ElevatedButton(
      onPressed: _placeOrder,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF728A9A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        padding: const EdgeInsets.symmetric(vertical: 15),
        minimumSize: const Size(double.infinity, 50),
      ),
      child: const Text(
        'Place Order',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }
}