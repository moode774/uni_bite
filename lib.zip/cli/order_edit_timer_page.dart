import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'shopping_cart_page.dart';
import 'order_tracking_page.dart';

class EditCancelOrderPage extends StatefulWidget {
  const EditCancelOrderPage({super.key});

  @override
  _EditCancelOrderPageState createState() => _EditCancelOrderPageState();
}

class _EditCancelOrderPageState extends State<EditCancelOrderPage> {
  int _secondsRemaining = 30;
  late Timer _timer;
  bool _showOrderReceived = false;

  String? userFirstName;
  String? userLastName;
  String? userEmail;
  String? userPhone;

  @override
  void initState() {
    super.initState();
    _startTimer();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final orderId = ModalRoute.of(context)?.settings.arguments as String? ?? "";
      if (orderId.isNotEmpty) {
        _fetchOrderAndUserData(orderId);
      }
    });
  }

  Future<void> _fetchOrderAndUserData(String orderId) async {
    try {
      final orderDoc = await FirebaseFirestore.instance
          .collection('Orders')
          .doc(orderId)
          .get();

      if (!orderDoc.exists) return;

      final orderData = orderDoc.data()!;
      final userId = orderData['user_id'];

      final userDoc = await FirebaseFirestore.instance
          .collection('Users')
          .doc(userId)
          .get();

      if (!userDoc.exists) return;

      final userData = userDoc.data()!;
      setState(() {
        userFirstName = userData['first_name'];
        userLastName = userData['last_name'];
        userEmail = userData['email'];
        userPhone = userData['phone'];
      });
    } catch (e) {
      debugPrint('Error fetching order/user data: $e');
    }
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining > 0) {
        setState(() {
          _secondsRemaining--;
        });
      } else {
        _timer.cancel();
        _showOrderReceivedScreen();
      }
    });
  }

  void _showOrderReceivedScreen() {
    setState(() {
      _showOrderReceived = true;
    });

    Timer(const Duration(seconds: 3), () {
      if (mounted && _showOrderReceived) {
        _navigateToOrderStatus();
      }
    });
  }

  void _navigateToOrderStatus() {
    final orderId = ModalRoute.of(context)?.settings.arguments as String? ?? "";
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => OrderStatusPage(orderId: orderId),
      ),
    );
  }

  Future<void> _cancelOrder(String orderId) async {
    try {
      await FirebaseFirestore.instance
          .collection('Orders')
          .doc(orderId)
          .update({'status': 'cancelled'});

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) =>
              OrderStatusPage(orderId: orderId, isCancelled: true),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error cancelling order: $e')),
      );
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final orderId = ModalRoute.of(context)?.settings.arguments as String? ?? "";

    if (!_showOrderReceived) {
      return _buildMainTimerUI(orderId);
    } else {
      return _buildOrderReceivedUI(orderId);
    }
  }

  Widget _buildMainTimerUI(String orderId) {
    double percent = _secondsRemaining / 30;

    return Scaffold(
      backgroundColor: const Color(0xFFFAF6F0),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF6F0),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF2A3E5F)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          " ",
          style: TextStyle(
            color: Color(0xFF2A3E5F),
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (userFirstName != null && userLastName != null)
              Text("Customer: $userFirstName $userLastName"),
            if (userEmail != null) Text("Email: $userEmail"),
            if (userPhone != null) Text("Phone: $userPhone"),
            const SizedBox(height: 20),
            _buildTimerWidget(percent),
            const SizedBox(height: 20),
            const Text(
              "You have 30 seconds to Edit, Cancel, or Skip Time.",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Color(0xFF65768B),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _timer.cancel();
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CartPage(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2A3E5F),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text("Edit"),
                ),
                ElevatedButton(
                  onPressed: () {
                    _timer.cancel();
                    _cancelOrder(orderId);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2A3E5F),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_timer.isActive) {
                      _timer.cancel();
                    }
                    _showOrderReceivedScreen();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2A3E5F),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text("Skip Time"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimerWidget(double percent) {
    return Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          width: 120,
          height: 120,
          child: CircularProgressIndicator(
            value: percent,
            strokeWidth: 8,
            color: const Color(0xFF2A3E5F),
            backgroundColor: Colors.grey.shade300,
          ),
        ),
        Text(
          '$_secondsRemaining',
          style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _buildOrderReceivedUI(String orderId) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9EAE6),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Thank You!",
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2A3E5F),
                ),
              ),
              const SizedBox(height: 5),
              const Text(
                "Order received.",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2A3E5F),
                ),
              ),
              const SizedBox(height: 15),
              Image.asset(
                "assets/cart.png",
                width: 220,
                color: const Color(0xFF2A3E5F),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  _showOrderReceived = false;
                  _navigateToOrderStatus();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2A3E5F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text("Skip"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
