// main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'cli/all_stores_page.dart';
import 'cli/signup.dart';
import 'cli/shopping_cart_page.dart';
import 'cli/add_payment_card_page.dart';
import 'cli/payment_methods_page.dart';
import 'cli/order_edit_timer_page.dart';
import 'cli/order_history_page.dart';
import 'cli/rating_feedback_page.dart';
import 'cli/menu_shop_page.dart';
import 'cli/product_detail_page.dart';
import 'cli/order_tracking_page.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Restaurant Ordering App',
      debugShowCheckedModeBanner: false,
    
      home: const Signup(),
      routes: {
        '/signup': (context) => const Signup(),
        '/stores': (context) => const AllStoresPage(),
        
        '/shoppingCart': (context) => const CartPage(),
        '/addPayment': (context) => const AddPayment(),
        '/paymentMethod': (context) => PaymentMethodPage(),
        '/orderEditTimer': (context) => EditCancelOrderPage(),
        '/orderHistory': (context) => OrdersScreen(),
        '/ratingFeedback': (context) => RatingFeedbackPage(),
        '/menuShop': (context) => MenuShopPage(storeDocId: 'demo'),
        '/productDetail': (context) => ProductDetailPage(
          productDocId: '',
          title: '',
          price: '',
          calories: '',
          imagePath: '',
          storeId: '',
        ),
        '/orderTracking': (context) => OrderStatusPage(),
      },
    );
  }
}
